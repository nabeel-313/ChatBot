
class Config:
    MODEL_NAME = "gemini-2.0-flash-lite"
    TEMP = "0.7"
    MAX_TOKEN = "1000"
    TIME_OUT=None,
    MAX_RETRIES=3,

