from setuptools import setup, find_packages

setup(
    name="Chatbot",
    version="0.0.0",
    author="Nabeel Ahmed",
    author_email="mominnabeelahmed123@gmail.com",
    packages=find_packages()
)
